#!/usr/bin/env python
# -*- coding: UTF-8 -*-

data_url = "http://professionnels.ign.fr/DISPLAY/000/528/175/5281750/GEOFLADept_FR_Corse_AV_L93.zip"
tablename = "departements"
shpfile = "departement"
coding = "CP1252"
prj = "2154"
sqlitedatabase = "france.sqlite"

